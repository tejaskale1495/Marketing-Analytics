library(robotstxt) # To check scraping permissions
library(rvest)     # Scraping data
library(XML)       # Parsing of HTML/XML files
library(dplyr)     # Filtering and reordering the data
library(stringr)   # String manipulation
library(ggplot2)   # Creating charts
library(plotly)    # Making charts interactive
library(tidyverse) # General-purpose data wrangling
library(rebus)     # Verbose regular expressions
library(lubridate) # Eases DateTime manipulation

#to check the scraping permissions
paths_allowed("https://www.gumtree.com/")


#Initializing Urls for scraping and pagination

url_Exeter <-      'https://www.gumtree.com/search?search_category=property-to-rent&search_location=exeter&page='
url_Leeds <-       'https://www.gumtree.com/search?search_category=property-to-rent&search_location=leeds&page='
url_Manchester <-  'https://www.gumtree.com/search?search_category=property-to-rent&search_location=manchester&page='
url_Glasgow <-     'https://www.gumtree.com/search?search_category=property-to-rent&search_location=glasgow&page='
url_Southampton <- 'https://www.gumtree.com/search?search_category=property-to-rent&search_location=southampton&page='
url_Bristol <-     'https://www.gumtree.com/search?search_category=property-to-rent&search_location=bristol&page='
url_EndsHere <- '&distance=0.0001'
url_Birmingham <-  'https://www.gumtree.com/search?search_category=property-to-rent&search_location=birmingham&page='
url_berminghamEnds <- '&sort=price_highest_first'


##################################### Finding Max paginaiton number ###############################
i=1

#Exeter
#creating a dynamic url
E_url <- paste(url_Exeter,i,url_EndsHere,sep = "")
#creating a vector to store the scraped data
pageList <- vector()
#scraping data from the url formed above with the help of html tags found by inspecting the website page
pageList <- c(read_html(E_url) %>%
                html_nodes(".pagination-page") %>%
                html_text())
#Sys.sleep(2)
#printing scraped data
pageList
#unlisting the data stored above which was a list
pageList <- unlist(trimws(pageList))
#finding the last number from the list to find the max pagination number
Exeter_maxPage <- as.integer(tail(pageList,n=1))
Exeter_maxPage


#Leeds
L_url <- paste(url_Leeds,i,url_EndsHere,sep = "")
pageList <- vector()
pageList <- c(read_html(L_url) %>%
                html_nodes(".pagination-page") %>%
                html_text())
#Sys.sleep(2)
pageList <- unlist(trimws(pageList))
Leeds_maxPage <- as.integer(tail(pageList,n=1))
Leeds_maxPage

#Manchester
M_url <- paste(url_Manchester,i,url_EndsHere,sep = "")
#M_url
pageList <- vector()
pageList <- c(read_html(M_url) %>%
                html_nodes(".pagination-page") %>%
                html_text())
pageList <- unlist(trimws(pageList))
Manchester_maxPage <- as.integer(tail(pageList,n=1))
Manchester_maxPage

#Glasgow
G_url <- paste(url_Glasgow,i,url_EndsHere,sep = "")
G_url
pageList <- vector()
pageList <- c(read_html(G_url) %>%
                html_nodes(".pagination-page") %>%
                html_text())
pageList <- unlist(trimws(pageList))
Glasgow_maxPage <- as.integer(tail(pageList,n=1))
Glasgow_maxPage

#Southampton
S_url <- paste(url_Southampton,i,url_EndsHere,sep = "")
pageList <- vector()
pageList <- c(read_html(S_url) %>%
                html_nodes(".pagination-page") %>%
                html_text())
pageList <- unlist(trimws(pageList))
Southampton_maxPage <- as.integer(tail(pageList,n=1))
Southampton_maxPage

#Bristol
url_Bristol
Br_url <- paste(url_Bristol,i,url_EndsHere,sep = "")
Br_url
pageList <- vector()
pageList <- c(read_html(Br_url) %>%
                html_nodes(".pagination-page") %>%
                html_text())
pageList <- unlist(trimws(pageList))
Bristol_maxPage <- as.integer(tail(pageList,n=1))
Bristol_maxPage

#Birmingham
Bi_url <- paste(url_Birmingham,i,url_berminghamEnds,sep = "")
Bi_url
pageList <- vector()
pageList <- c(read_html(Bi_url) %>%
                html_nodes(".pagination-page") %>%
                html_text())
pageList
pageList <- unlist(trimws(pageList))
Birmingham_maxPage <- as.integer(tail(pageList,n=1))
Birmingham_maxPage

#Max pagination count from all cities
maxPages_All <- max(Exeter_maxPage,Leeds_maxPage,Manchester_maxPage,Glasgow_maxPage,Southampton_maxPage,Bristol_maxPage,Birmingham_maxPage)
maxPages_All


################################# Data for exeter ###########################

# Creating required vectors
Exeter_content <- vector()
#printing max page listed for the city search which was scraped in above section
Exeter_maxPage

#scrape data from all the pages
for(i in seq(from=1,to=Exeter_maxPage,by=1)){
  #forming the dynamic url for each page to scrape data pagewise
  URL_temp <- paste0(url_Exeter,i,url_EndsHere)
  print(URL_temp)
  #scraping data from the url formed above
  Exeter_content <- c(Exeter_content,read_html(URL_temp) %>%
                        html_nodes(".listing-content") %>%
                        html_text())
  print(paste("Page Number Scraped:",i))
  }

#printing scraped data which is a list
Exeter_content
#saving the scraped data into a csv file
write.csv(Exeter_content,"Exeter_content.csv", row.names = TRUE)
#finding total records scraped
TotalContentLength <- length(Exeter_content)
#splitting the data which are separated by \n\n\n denoting end of a section forming a list
Exeter_content <- strsplit(Exeter_content, "\n\n\n")

#making data standard to have 10 values per element of the main list
#so here, the data is a list of lists.
#means, each element of a list holds a list value in it
#so making sure that, each element in the main list contains a list of 10 values
#making adjustment for agenty type which tells that whether the property is maintained by agency (1) or not (0)
for (i in 1:TotalContentLength) {
  elementLength <- length(Exeter_content[[i]][])
  #print(length(elementLength))
  if(elementLength==9){
    Exeter_content[[i]][10] <- Exeter_content[[i]][9]
    Exeter_content[[i]][9] <- Exeter_content[[i]][8]
    Exeter_content[[i]][8] <- Exeter_content[[i]][7]
    Exeter_content[[i]][7] <- Exeter_content[[i]][6]
    Exeter_content[[i]][6] <- Exeter_content[[i]][5]
    Exeter_content[[i]][5] <- Exeter_content[[i]][4]
    Exeter_content[[i]][4] <- 0
    i=i+1
  }
  else{
    Exeter_content[[i]][4] <- 1
    i=i+1
  }
  
}

#forming a vector of property titles :- 1st value of each element from the main list
Exeter_property_title <- trimws(unlist(lapply(Exeter_content,`[[`, 1)))
Exeter_property_title

#forming a vector of property location :- 2nd value of each element from the main list
Exeter_property_location <- trimws(unlist(lapply(Exeter_content,`[[`, 2)))
Exeter_property_location

#forming a vector of property description :- 3rd value of each element from the main list
Exeter_property_description <- trimws(unlist(lapply(Exeter_content,`[[`, 3)))
#removing new line character from the data
Exeter_property_description <- gsub("\n",'',Exeter_property_description)
Exeter_property_description

#forming a vector of agency involvement :- 4th value of each element from the main list
Exeter_property_isAgency <- trimws(unlist(lapply(Exeter_content,`[[`, 4)))
Exeter_property_isAgency

#forming a vector of property availability from :- 5th value of each element from the main list
Exeter_property_availableFrom <- trimws(unlist(lapply(Exeter_content,`[[`, 5)))
Exeter_property_availableFrom <- gsub("Date availableDate available: ", "", Exeter_property_availableFrom)
Exeter_property_availableFrom

#forming a vector of property type :- 6th value of each element from the main list
Exeter_property_type <- trimws(unlist(lapply(Exeter_content,`[[`, 6)))
Exeter_property_type <- gsub('Property type','',Exeter_property_type)
Exeter_property_type

#forming a vector of number of rooms :- 7th value of each element from the main list
Exeter_property_numberOfRooms <- trimws(unlist(lapply(Exeter_content,`[[`, 7)))
#removing unnecessary string content from the data
Exeter_property_numberOfRooms <- gsub("Number of bedrooms", "", Exeter_property_numberOfRooms)
Exeter_property_numberOfRooms <- gsub("Beds", "", Exeter_property_numberOfRooms)
Exeter_property_numberOfRooms <- gsub("Bed", "", Exeter_property_numberOfRooms)
Exeter_property_numberOfRooms <- gsub('Studio',0,Exeter_property_numberOfRooms)
Exeter_property_numberOfRooms

#forming a vector of rent and rent type :- 8th value of each element from the main list
Exeter_property_rentStr <- trimws(unlist(lapply(Exeter_content,`[[`, 8)))
Exeter_property_rentStr
#removing unnecessary string content from the data
Exeter_property_rentStr <- gsub(",", "", Exeter_property_rentStr)
Exeter_property_rentStr <- gsub("�", "", Exeter_property_rentStr)
#forming a vector for rent type as last 2 characters of the rentSTR vector:- pw (per week) or pm (per month)
Exeter_property_rentType <- str_sub(Exeter_property_rentStr,-2,-1)
Exeter_property_rentType
#for a vector for property rent by removing pw and pm string data from rentSTR
Exeter_property_rentStr <- gsub("pw", "", Exeter_property_rentStr)
Exeter_property_rentStr <- gsub("pm", "", Exeter_property_rentStr)
#typecasting the rent value from string to integer
Exeter_property_rent <- as.integer(Exeter_property_rentStr)
Exeter_property_rent

#combining all the vectors created above to form a dataframe
Exeter_data_combined <- data.frame(Exeter_property_title,Exeter_property_location,Exeter_property_description,Exeter_property_availableFrom,Exeter_property_type,Exeter_property_numberOfRooms,Exeter_property_rent,Exeter_property_rentType,Exeter_property_isAgency)
Exeter_data_combined

#saving the created dataframe into a csv file
write.csv(Exeter_data_combined,"Exeter_data_combined.csv", row.names = TRUE)


################################# Data for leeds #################################

# Creating required vectors

Leeds_content <- vector()
Leeds_maxPage
for(i in seq(from=1,to=Leeds_maxPage,by=1)){
  
  URL_temp <- paste0(url_Leeds,i,url_EndsHere)
  print(URL_temp)
  Leeds_content <- c(Leeds_content,read_html(URL_temp) %>%
                        html_nodes(".listing-content") %>%
                        html_text())
  print(paste("Page Number Scraped:",i))
}

Leeds_content
write.csv(Leeds_content,"Leeds_content.csv", row.names = TRUE)


TotalContentLength <- length(Leeds_content)
TotalContentLength

Leeds_content <- strsplit(Leeds_content, "\n\n\n")

for (i in 1:TotalContentLength) {
  elementLength <- length(Leeds_content[[i]][])
  #print(length(elementLength))
  if(elementLength==9){
    Leeds_content[[i]][10] <- Leeds_content[[i]][9]
    Leeds_content[[i]][9] <- Leeds_content[[i]][8]
    Leeds_content[[i]][8] <- Leeds_content[[i]][7]
    Leeds_content[[i]][7] <- Leeds_content[[i]][6]
    Leeds_content[[i]][6] <- Leeds_content[[i]][5]
    Leeds_content[[i]][5] <- Leeds_content[[i]][4]
    Leeds_content[[i]][4] <- 0
    i=i+1
  }
  else{
    Leeds_content[[i]][4] <- 1
    i=i+1
  }
  
}


Leeds_property_title <- trimws(unlist(lapply(Leeds_content,`[[`, 1)))
Leeds_property_title
Leeds_property_location <- trimws(unlist(lapply(Leeds_content,`[[`, 2)))
Leeds_property_location
Leeds_property_description <- trimws(unlist(lapply(Leeds_content,`[[`, 3)))
Leeds_property_description <- gsub("\n",'',Leeds_property_description)
Leeds_property_description
Leeds_property_isAgency <- trimws(unlist(lapply(Leeds_content,`[[`, 4)))
Leeds_property_isAgency
Leeds_property_availableFrom <- trimws(unlist(lapply(Leeds_content,`[[`, 5)))
Leeds_property_availableFrom <- gsub("Date availableDate available: ", "", Leeds_property_availableFrom)
Leeds_property_availableFrom
Leeds_property_type <- trimws(unlist(lapply(Leeds_content,`[[`, 6)))
Leeds_property_type <- gsub('Property type','',Leeds_property_type)
Leeds_property_type
Leeds_property_numberOfRooms <- trimws(unlist(lapply(Leeds_content,`[[`, 7)))
Leeds_property_numberOfRooms <- gsub("Number of bedrooms", "", Leeds_property_numberOfRooms)
Leeds_property_numberOfRooms <- gsub("Beds", "", Leeds_property_numberOfRooms)
Leeds_property_numberOfRooms <- gsub("Bed", "", Leeds_property_numberOfRooms)
Leeds_property_numberOfRooms <- gsub('Studio',0,Leeds_property_numberOfRooms)
Leeds_property_numberOfRooms
Leeds_property_rentStr <- trimws(unlist(lapply(Leeds_content,`[[`, 8)))
Leeds_property_rentStr
Leeds_property_rentStr <- gsub(",", "", Leeds_property_rentStr)
Leeds_property_rentStr <- gsub("�", "", Leeds_property_rentStr)
Leeds_property_rentType <- str_sub(Leeds_property_rentStr,-2,-1)
Leeds_property_rentType
Leeds_property_rentStr <- gsub("pw", "", Leeds_property_rentStr)
Leeds_property_rentStr <- gsub("pm", "", Leeds_property_rentStr)
Leeds_property_rent <- as.integer(Leeds_property_rentStr)
Leeds_property_rentType
Leeds_property_rent

Leeds_data_combined <- data.frame(Leeds_property_title,Leeds_property_location,Leeds_property_description,Leeds_property_availableFrom,Leeds_property_type,Leeds_property_numberOfRooms,Leeds_property_rent,Leeds_property_rentType,Leeds_property_isAgency)
Leeds_data_combined

write.csv(Leeds_data_combined,"Leeds_data_combined.csv", row.names = TRUE)


################################# Data for manchester #################################

# Creating required vectors

Manchester_content <- vector()
Manchester_maxPage
for(i in seq(from=1,to=Manchester_maxPage,by=1)){
  
  URL_temp <- paste0(url_Manchester,i,url_EndsHere)
  print(URL_temp)
  Manchester_content <- c(Manchester_content,read_html(URL_temp) %>%
                       html_nodes(".listing-content") %>%
                       html_text())
  print(paste("Page Number Scraped:",i))
}

Manchester_content
write.csv(Manchester_content,"Manchester_content.csv", row.names = TRUE)

TotalContentLength <- length(Manchester_content)
TotalContentLength

Manchester_content <- strsplit(Manchester_content, "\n\n\n")
Manchester_content


for (i in 1:TotalContentLength) {
  elementLength <- length(Manchester_content[[i]][])
  #print(length(elementLength))
  if(elementLength==9){
    Manchester_content[[i]][10] <- Manchester_content[[i]][9]
    Manchester_content[[i]][9] <- Manchester_content[[i]][8]
    Manchester_content[[i]][8] <- Manchester_content[[i]][7]
    Manchester_content[[i]][7] <- Manchester_content[[i]][6]
    Manchester_content[[i]][6] <- Manchester_content[[i]][5]
    Manchester_content[[i]][5] <- Manchester_content[[i]][4]
    Manchester_content[[i]][4] <- 0
    i=i+1
  }
  else{
    Manchester_content[[i]][4] <- 1
    i=i+1
  }
  
}

Manchester_property_title <- trimws(unlist(lapply(Manchester_content,`[[`, 1)))
Manchester_property_title
Manchester_property_location <- trimws(unlist(lapply(Manchester_content,`[[`, 2)))
Manchester_property_location
Manchester_property_description <- trimws(unlist(lapply(Manchester_content,`[[`, 3)))
Manchester_property_description <- gsub("\n",'',Manchester_property_description)
Manchester_property_description
Manchester_property_isAgency <- trimws(unlist(lapply(Manchester_content,`[[`, 4)))
Manchester_property_isAgency
Manchester_property_availableFrom <- trimws(unlist(lapply(Manchester_content,`[[`, 5)))
Manchester_property_availableFrom <- gsub("Date availableDate available: ", "", Manchester_property_availableFrom)
Manchester_property_availableFrom
Manchester_property_type <- trimws(unlist(lapply(Manchester_content,`[[`, 6)))
Manchester_property_type <- gsub('Property type','',Manchester_property_type)
Manchester_property_type
Manchester_property_numberOfRooms <- trimws(unlist(lapply(Manchester_content,`[[`, 7)))
Manchester_property_numberOfRooms <- gsub("Number of bedrooms", "", Manchester_property_numberOfRooms)
Manchester_property_numberOfRooms <- gsub("Beds", "", Manchester_property_numberOfRooms)
Manchester_property_numberOfRooms <- gsub("Bed", "", Manchester_property_numberOfRooms)
Manchester_property_numberOfRooms <- gsub('Studio',0,Manchester_property_numberOfRooms)
Manchester_property_numberOfRooms
Manchester_property_rentStr <- trimws(unlist(lapply(Manchester_content,`[[`, 8)))
Manchester_property_rentStr
Manchester_property_rentStr <- gsub(",", "", Manchester_property_rentStr)
Manchester_property_rentStr <- gsub("�", "", Manchester_property_rentStr)
Manchester_property_rentType <- str_sub(Manchester_property_rentStr,-2,-1)
Manchester_property_rentType
Manchester_property_rentStr <- gsub("pw", "", Manchester_property_rentStr)
Manchester_property_rentStr <- gsub("pm", "", Manchester_property_rentStr)
Manchester_property_rent <- as.integer(Manchester_property_rentStr)
Manchester_property_rentType
Manchester_property_rent

Manchester_data_combined <- data.frame(Manchester_property_title,Manchester_property_location,Manchester_property_description,Manchester_property_availableFrom,Manchester_property_type,Manchester_property_numberOfRooms,Manchester_property_rent,Manchester_property_rentType,Manchester_property_isAgency)
Manchester_data_combined

write.csv(Manchester_data_combined,"Manchester_data_combined.csv", row.names = TRUE)

################################# Data for birmingham #################################

# Creating required vectors
Birmingham_content <- vector()
Birmingham_maxPage
for(i in seq(from=1,to=Birmingham_maxPage,by=1)){
  
  URL_temp <- paste0(url_Birmingham,i,url_berminghamEnds)
  print(URL_temp)
  Birmingham_content <- c(Birmingham_content,read_html(URL_temp) %>%
                            html_nodes(".listing-content") %>%
                            html_text())
  print(paste("Page Number Scraped:",i))
}

Birmingham_content
write.csv(Birmingham_content,"Birmingham_content.csv", row.names = TRUE)

TotalContentLength <- length(Birmingham_content)
TotalContentLength

Birmingham_content <- strsplit(Birmingham_content, "\n\n\n")
Birmingham_content


for (i in 1:TotalContentLength) {
  elementLength <- length(Birmingham_content[[i]][])
  #print(length(elementLength))
  if(elementLength==9){
    Birmingham_content[[i]][10] <- Birmingham_content[[i]][9]
    Birmingham_content[[i]][9] <- Birmingham_content[[i]][8]
    Birmingham_content[[i]][8] <- Birmingham_content[[i]][7]
    Birmingham_content[[i]][7] <- Birmingham_content[[i]][6]
    Birmingham_content[[i]][6] <- Birmingham_content[[i]][5]
    Birmingham_content[[i]][5] <- Birmingham_content[[i]][4]
    Birmingham_content[[i]][4] <- 0
    i=i+1
  }
  else{
    Birmingham_content[[i]][4] <- 1
    i=i+1
  }
  
}

Birmingham_property_title <- trimws(unlist(lapply(Birmingham_content,`[[`, 1)))
Birmingham_property_title
Birmingham_property_location <- trimws(unlist(lapply(Birmingham_content,`[[`, 2)))
Birmingham_property_location
Birmingham_property_description <- trimws(unlist(lapply(Birmingham_content,`[[`, 3)))
Birmingham_property_description <- gsub("\n",'',Birmingham_property_description)
Birmingham_property_description
Birmingham_property_isAgency <- trimws(unlist(lapply(Birmingham_content,`[[`, 4)))
Birmingham_property_isAgency
Birmingham_property_availableFrom <- trimws(unlist(lapply(Birmingham_content,`[[`, 5)))
Birmingham_property_availableFrom <- gsub("Date availableDate available: ", "", Birmingham_property_availableFrom)
Birmingham_property_availableFrom
Birmingham_property_type <- trimws(unlist(lapply(Birmingham_content,`[[`, 6)))
Birmingham_property_type <- gsub('Property type','',Birmingham_property_type)
Birmingham_property_type
Birmingham_property_numberOfRooms <- trimws(unlist(lapply(Birmingham_content,`[[`, 7)))
Birmingham_property_numberOfRooms <- gsub("Number of bedrooms", "", Birmingham_property_numberOfRooms)
Birmingham_property_numberOfRooms <- gsub("Beds", "", Birmingham_property_numberOfRooms)
Birmingham_property_numberOfRooms <- gsub("Bed", "", Birmingham_property_numberOfRooms)
Birmingham_property_numberOfRooms <- gsub('Studio',0,Birmingham_property_numberOfRooms)
Birmingham_property_numberOfRooms
Birmingham_property_rentStr <- trimws(unlist(lapply(Birmingham_content,`[[`, 8)))
Birmingham_property_rentStr
Birmingham_property_rentStr <- gsub(",", "", Birmingham_property_rentStr)
Birmingham_property_rentStr <- gsub("�", "", Birmingham_property_rentStr)
Birmingham_property_rentType <- str_sub(Birmingham_property_rentStr,-2,-1)
Birmingham_property_rentType
Birmingham_property_rentStr <- gsub("pw", "", Birmingham_property_rentStr)
Birmingham_property_rentStr <- gsub("pm", "", Birmingham_property_rentStr)
Birmingham_property_rent <- as.integer(Birmingham_property_rentStr)
Birmingham_property_rentType
Birmingham_property_rent

Birmingham_data_combined <- data.frame(Birmingham_property_title,Birmingham_property_location,Birmingham_property_description,Birmingham_property_availableFrom,Birmingham_property_type,Birmingham_property_numberOfRooms,Birmingham_property_rent,Birmingham_property_rentType,Birmingham_property_isAgency)
Birmingham_data_combined

write.csv(Birmingham_data_combined,"Birmingham_data_combined.csv", row.names = TRUE)

################################# Data for bristol #################################

# Creating required vectors

Bristol_maxPage
Bristol_content <- vector()
for(i in seq(from=1,to=Bristol_maxPage,by=1)){
  
  URL_temp <- paste0(url_Bristol,i,url_EndsHere)
  print(URL_temp)
  Bristol_content <- c(Bristol_content,read_html(URL_temp) %>%
                         html_nodes(".listing-content") %>%
                         html_text())
  print(paste("Page Number Scraped:",i))
}

Bristol_content
write.csv(Bristol_content,"Bristol_content.csv", row.names = TRUE)


TotalContentLength <- length(Bristol_content)
TotalContentLength

Bristol_content <- strsplit(Bristol_content, "\n\n\n")
Bristol_content


for (i in 1:TotalContentLength) {
  elementLength <- length(Bristol_content[[i]][])
  #print(length(elementLength))
  if(elementLength==9){
    Bristol_content[[i]][10] <- Bristol_content[[i]][9]
    Bristol_content[[i]][9] <- Bristol_content[[i]][8]
    Bristol_content[[i]][8] <- Bristol_content[[i]][7]
    Bristol_content[[i]][7] <- Bristol_content[[i]][6]
    Bristol_content[[i]][6] <- Bristol_content[[i]][5]
    Bristol_content[[i]][5] <- Bristol_content[[i]][4]
    Bristol_content[[i]][4] <- 0
    i=i+1
  }
  else{
    Bristol_content[[i]][4] <- 1
    i=i+1
  }
  
}

Bristol_property_title <- trimws(unlist(lapply(Bristol_content,`[[`, 1)))
Bristol_property_title
Bristol_property_location <- trimws(unlist(lapply(Bristol_content,`[[`, 2)))
Bristol_property_location
Bristol_property_description <- trimws(unlist(lapply(Bristol_content,`[[`, 3)))
Bristol_property_description <- gsub("\n",'',Bristol_property_description)
Bristol_property_description
Bristol_property_isAgency <- trimws(unlist(lapply(Bristol_content,`[[`, 4)))
Bristol_property_isAgency
Bristol_property_availableFrom <- trimws(unlist(lapply(Bristol_content,`[[`, 5)))
Bristol_property_availableFrom <- gsub("Date availableDate available: ", "", Bristol_property_availableFrom)
Bristol_property_availableFrom
Bristol_property_type <- trimws(unlist(lapply(Bristol_content,`[[`, 6)))
Bristol_property_type <- gsub('Property type','',Bristol_property_type)
Bristol_property_type
Bristol_property_numberOfRooms <- trimws(unlist(lapply(Bristol_content,`[[`, 7)))
Bristol_property_numberOfRooms <- gsub("Number of bedrooms", "", Bristol_property_numberOfRooms)
Bristol_property_numberOfRooms <- gsub("Beds", "", Bristol_property_numberOfRooms)
Bristol_property_numberOfRooms <- gsub("Bed", "", Bristol_property_numberOfRooms)
Bristol_property_numberOfRooms <- gsub('Studio',0,Bristol_property_numberOfRooms)
Bristol_property_numberOfRooms
Bristol_property_rentStr <- trimws(unlist(lapply(Bristol_content,`[[`, 8)))
Bristol_property_rentStr
Bristol_property_rentStr <- gsub(",", "", Bristol_property_rentStr)
Bristol_property_rentStr <- gsub("�", "", Bristol_property_rentStr)
Bristol_property_rentType <- str_sub(Bristol_property_rentStr,-2,-1)
Bristol_property_rentType
Bristol_property_rentStr <- gsub("pw", "", Bristol_property_rentStr)
Bristol_property_rentStr <- gsub("pm", "", Bristol_property_rentStr)
Bristol_property_rent <- as.integer(Bristol_property_rentStr)
Bristol_property_rentType
Bristol_property_rent

Bristol_data_combined <- data.frame(Bristol_property_title,Bristol_property_location,Bristol_property_description,Bristol_property_availableFrom,Bristol_property_type,Bristol_property_numberOfRooms,Bristol_property_rent,Bristol_property_rentType,Bristol_property_isAgency)
Bristol_data_combined

write.csv(Bristol_data_combined,"Bristol_data_combined.csv", row.names = TRUE)

################################# Data for glasgow #################################

# Creating required vectors

Glasgow_maxPage
Glasgow_content <- vector()
for(i in seq(from=1,to=Glasgow_maxPage,by=1)){
  
  URL_temp <- paste0(url_Glasgow,i,url_EndsHere)
  print(URL_temp)
  Glasgow_content <- c(Glasgow_content,read_html(URL_temp) %>%
                         html_nodes(".listing-content") %>%
                         html_text())
  print(paste("Page Number Scraped:",i))
}

Glasgow_content
write.csv(Glasgow_content,"Glasgow_content.csv", row.names = TRUE)

TotalContentLength <- length(Glasgow_content)
TotalContentLength

Glasgow_content <- strsplit(Glasgow_content, "\n\n\n")
Glasgow_content


for (i in 1:TotalContentLength) {
  elementLength <- length(Glasgow_content[[i]][])
  #print(length(elementLength))
  if(elementLength==9){
    Glasgow_content[[i]][10] <- Glasgow_content[[i]][9]
    Glasgow_content[[i]][9] <- Glasgow_content[[i]][8]
    Glasgow_content[[i]][8] <- Glasgow_content[[i]][7]
    Glasgow_content[[i]][7] <- Glasgow_content[[i]][6]
    Glasgow_content[[i]][6] <- Glasgow_content[[i]][5]
    Glasgow_content[[i]][5] <- Glasgow_content[[i]][4]
    Glasgow_content[[i]][4] <- 0
    i=i+1
  }
  else{
    Glasgow_content[[i]][4] <- 1
    i=i+1
  }
  
}

Glasgow_property_title <- trimws(unlist(lapply(Glasgow_content,`[[`, 1)))
Glasgow_property_title
Glasgow_property_location <- trimws(unlist(lapply(Glasgow_content,`[[`, 2)))
Glasgow_property_location
Glasgow_property_description <- trimws(unlist(lapply(Glasgow_content,`[[`, 3)))
Glasgow_property_description <- gsub("\n",'',Glasgow_property_description)
Glasgow_property_description
Glasgow_property_isAgency <- trimws(unlist(lapply(Glasgow_content,`[[`, 4)))
Glasgow_property_isAgency
Glasgow_property_availableFrom <- trimws(unlist(lapply(Glasgow_content,`[[`, 5)))
Glasgow_property_availableFrom <- gsub("Date availableDate available: ", "", Glasgow_property_availableFrom)
Glasgow_property_availableFrom
Glasgow_property_type <- trimws(unlist(lapply(Glasgow_content,`[[`, 6)))
Glasgow_property_type <- gsub('Property type','',Glasgow_property_type)
Glasgow_property_type
Glasgow_property_numberOfRooms <- trimws(unlist(lapply(Glasgow_content,`[[`, 7)))
Glasgow_property_numberOfRooms <- gsub("Number of bedrooms", "", Glasgow_property_numberOfRooms)
Glasgow_property_numberOfRooms <- gsub("Beds", "", Glasgow_property_numberOfRooms)
Glasgow_property_numberOfRooms <- gsub("Bed", "", Glasgow_property_numberOfRooms)
Glasgow_property_numberOfRooms <- gsub('Studio',0,Glasgow_property_numberOfRooms)
Glasgow_property_numberOfRooms
Glasgow_property_rentStr <- trimws(unlist(lapply(Glasgow_content,`[[`, 8)))
Glasgow_property_rentStr
Glasgow_property_rentStr <- gsub(",", "", Glasgow_property_rentStr)
Glasgow_property_rentStr <- gsub("�", "", Glasgow_property_rentStr)
Glasgow_property_rentType <- str_sub(Glasgow_property_rentStr,-2,-1)
Glasgow_property_rentType
Glasgow_property_rentStr <- gsub("pw", "", Glasgow_property_rentStr)
Glasgow_property_rentStr <- gsub("pm", "", Glasgow_property_rentStr)
Glasgow_property_rent <- as.integer(Glasgow_property_rentStr)
Glasgow_property_rentType
Glasgow_property_rent

Glasgow_data_combined <- data.frame(Glasgow_property_title,Glasgow_property_location,Glasgow_property_description,Glasgow_property_availableFrom,Glasgow_property_type,Glasgow_property_numberOfRooms,Glasgow_property_rent,Glasgow_property_rentType,Glasgow_property_isAgency)
Glasgow_data_combined

write.csv(Glasgow_data_combined,"Glasgow_data_combined.csv", row.names = TRUE)

################################# Data for southampton #################################

# Creating required vectors

Southampton_maxPage
Southampton_content <- vector()
for(i in seq(from=1,to=Southampton_maxPage,by=1)){
  
  URL_temp <- paste0(url_Southampton,i,url_EndsHere)
  print(URL_temp)
  Southampton_content <- c(Southampton_content,read_html(URL_temp) %>%
                             html_nodes(".listing-content") %>%
                             html_text())
  print(paste("Page Number Scraped:",i))
}

Southampton_content
write.csv(Southampton_content,"Southampton_content.csv", row.names = TRUE)

TotalContentLength <- length(Southampton_content)
TotalContentLength

Southampton_content <- strsplit(Southampton_content, "\n\n\n")
Southampton_content


for (i in 1:TotalContentLength) {
  elementLength <- length(Southampton_content[[i]][])
  #print(length(elementLength))
  if(elementLength==9){
    Southampton_content[[i]][10] <- Southampton_content[[i]][9]
    Southampton_content[[i]][9] <- Southampton_content[[i]][8]
    Southampton_content[[i]][8] <- Southampton_content[[i]][7]
    Southampton_content[[i]][7] <- Southampton_content[[i]][6]
    Southampton_content[[i]][6] <- Southampton_content[[i]][5]
    Southampton_content[[i]][5] <- Southampton_content[[i]][4]
    Southampton_content[[i]][4] <- 0
    i=i+1
  }
  else{
    Southampton_content[[i]][4] <- 1
    i=i+1
  }
  
}

Southampton_property_title <- trimws(unlist(lapply(Southampton_content,`[[`, 1)))
Southampton_property_title
Southampton_property_location <- trimws(unlist(lapply(Southampton_content,`[[`, 2)))
Southampton_property_location
Southampton_property_description <- trimws(unlist(lapply(Southampton_content,`[[`, 3)))
Southampton_property_description <- gsub("\n",'',Southampton_property_description)
Southampton_property_description
Southampton_property_isAgency <- trimws(unlist(lapply(Southampton_content,`[[`, 4)))
Southampton_property_isAgency
Southampton_property_availableFrom <- trimws(unlist(lapply(Southampton_content,`[[`, 5)))
Southampton_property_availableFrom <- gsub("Date availableDate available: ", "", Southampton_property_availableFrom)
Southampton_property_availableFrom
Southampton_property_type <- trimws(unlist(lapply(Southampton_content,`[[`, 6)))
Southampton_property_type <- gsub('Property type','',Southampton_property_type)
Southampton_property_type
Southampton_property_numberOfRooms <- trimws(unlist(lapply(Southampton_content,`[[`, 7)))
Southampton_property_numberOfRooms <- gsub("Number of bedrooms", "", Southampton_property_numberOfRooms)
Southampton_property_numberOfRooms <- gsub("Beds", "", Southampton_property_numberOfRooms)
Southampton_property_numberOfRooms <- gsub("Bed", "", Southampton_property_numberOfRooms)
Southampton_property_numberOfRooms <- gsub('Studio',0,Southampton_property_numberOfRooms)
Southampton_property_numberOfRooms
Southampton_property_rentStr <- trimws(unlist(lapply(Southampton_content,`[[`, 8)))
Southampton_property_rentStr
Southampton_property_rentStr <- gsub(",", "", Southampton_property_rentStr)
Southampton_property_rentStr <- gsub("�", "", Southampton_property_rentStr)
Southampton_property_rentType <- str_sub(Southampton_property_rentStr,-2,-1)
Southampton_property_rentType
Southampton_property_rentStr <- gsub("pw", "", Southampton_property_rentStr)
Southampton_property_rentStr <- gsub("pm", "", Southampton_property_rentStr)
Southampton_property_rent <- as.integer(Southampton_property_rentStr)
Southampton_property_rentType
Southampton_property_rent

Southampton_data_combined <- data.frame(Southampton_property_title,Southampton_property_location,Southampton_property_description,Southampton_property_availableFrom,Southampton_property_type,Southampton_property_numberOfRooms,Southampton_property_rent,Southampton_property_rentType,Southampton_property_isAgency)
Southampton_data_combined

write.csv(Southampton_data_combined,"Southampton_data_combined.csv", row.names = TRUE)

